const db = require("orio.db")
const config = require("../config.js");
module.exports = async (client) => {
let arr = true
    console.log(`Logged in as ${client.user.tag}!`);
    client.user.setActivity(`discord.gg/????`, { type: "WATCHING" });
    client.user.setStatus("online");
  
    const creq = require("request")
    db.delete("urlsniper")
  setInterval(async() => {
    if(db.get("urlsniper")){
      
    } else {
    if(config.status === "true") {
      if(client.guilds.cache.get(config.serverID)){
    if (client.guilds.cache.get(config.serverID).features.includes('VANITY_URL')) {
      if(config.url){
        if(client.guilds.cache.get(config.serverID).vanityURLCode === config.url){
          db.set("urlsniper", config.url)
          const csLOG = client.channels.cache.get(config.log)
          if(csLOG){
            csLOG.send({content: "<@"+config.authorID+">, **" + config.url + "** Url Başarıyla alındı bot çalışmayı durdu." })
            console.log(config.url +" Url Başarıyla alındı bot çalışmayı durdu.")
          } else {
            console.log(config.url +" Url Başarıyla alındı bot çalışmayı durdu.")
          }
        } else {
         client.fetchInvite(config.url).then(ub => {
          if(ub == "DiscordAPIError: Unknown Invite"){
  
          } else {
          console.log(`${config.url} Adlı URL Alınmayı Denendi Ama Başarısız Olundu.`)
          arr = false
           }
         }).catch(e => {})
        }
      } else {
        console.log('config.js içerisindeki "url" kısmını doldurun.')
      }  
    } else {
      console.log("ID'si girilen sunucu 3. seviye bir sunucu olmadığı için bot başlatılamadı!")
    }
      } else {
        console.log("ID Girilen Sunucu Bulunamadığı İçin Bot Başlatılamadı!")
      }
    } else {
      console.log('Botu Başlatmak İçin config.js Dosyasındaki Durum: "False" Yazdığı Yere "True" Yazmanız Gerekiyor!');
    }
    }

        if(!arr === false){
       const url = {
        url: `https://discord.com/api/v9/guilds/${config.serverID}/vanity-url`,
        body: {
          code: `${config.url}`
        },
        json: true,
        method: 'patch',
        headers: {
          "Authorization": `Bot ${config.TOKEN}`
        }
      };
      creq(url, (err, res, body) => {
        if (err) {
          return console.log(err);
        }
      })
        }
    
  }, config.botRun)
  
}
